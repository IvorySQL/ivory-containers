.. _gdalextendeddatatype_cpp:

================================================================================
GDALExtendedDataType C++ API
================================================================================

GDALExtendedDataType class
--------------------------

.. doxygenclass:: GDALExtendedDataType
   :project: api
   :members:

GDALEDTComponent class
----------------------

.. doxygenclass:: GDALEDTComponent
   :project: api
   :members:
