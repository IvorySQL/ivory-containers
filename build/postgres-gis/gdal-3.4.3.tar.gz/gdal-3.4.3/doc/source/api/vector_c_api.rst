.. _vector_c_api:

================================================================================
ogr_core.h and ogr_api.h: Vector C API
================================================================================

.. doxygenfile:: ogr_core.h
   :project: api

.. doxygenfile:: ogr_api.h
   :project: api
