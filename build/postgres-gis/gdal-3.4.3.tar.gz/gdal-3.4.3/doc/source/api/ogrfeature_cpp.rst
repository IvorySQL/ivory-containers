.. _ogrfeature_cpp:

================================================================================
OGRFeature C++ API
================================================================================

OGRFeature class
----------------

.. doxygenclass:: OGRFeature
   :project: api
   :members:

OGRFeatureDefn class
--------------------

.. doxygenclass:: OGRFeatureDefn
   :project: api
   :members:

OGRFieldDefn class
------------------

.. doxygenclass:: OGRFieldDefn
   :project: api
   :members:

OGRGeomFieldDefn class
----------------------

.. doxygenclass:: OGRGeomFieldDefn
   :project: api
   :members:

OGRFieldDomain class
--------------------

.. doxygenclass:: OGRFieldDomain
   :project: api
   :members:

OGRCodedFieldDomain class
+++++++++++++++++++++++++

.. doxygenclass:: OGRCodedFieldDomain
   :project: api
   :members:

OGRRangeFieldDomain class
+++++++++++++++++++++++++

.. doxygenclass:: OGRRangeFieldDomain
   :project: api
   :members:

OGRGlobFieldDomain class
++++++++++++++++++++++++

.. doxygenclass:: OGRGlobFieldDomain
   :project: api
   :members:
