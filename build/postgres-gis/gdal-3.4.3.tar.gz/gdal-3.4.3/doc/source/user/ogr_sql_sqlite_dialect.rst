.. _ogr_sql_sqlite_dialect:

================================================================================
OGR SQL dialect and SQLITE SQL dialect
================================================================================

.. toctree::
   :maxdepth: 1

   ogr_sql_dialect
   sql_sqlite_dialect
