.. _raster.fit:

================================================================================
FIT -- FIT
================================================================================

.. shortname:: FIT

.. built_in_by_default::

NOTE: Implemented as ``gdal/frmts/fit/fitdataset.cpp``.

Driver capabilities
-------------------

.. supports_createcopy::

.. supports_georeferencing::

.. supports_virtualio::
