# Testing TimescaleDB

- [Regression tests](pgtest/README.md)
- [Perl-based TAP tests](perl/README.md)
- [Background Worker Test Infrastructure](src/bgw/README.md)
