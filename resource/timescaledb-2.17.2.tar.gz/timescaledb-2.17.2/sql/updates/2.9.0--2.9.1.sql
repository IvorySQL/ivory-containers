GRANT SELECT ON _timescaledb_internal.job_errors to PUBLIC;
