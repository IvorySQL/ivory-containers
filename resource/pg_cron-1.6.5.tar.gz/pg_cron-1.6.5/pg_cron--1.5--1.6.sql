/* no SQL changes in 1.6 */
