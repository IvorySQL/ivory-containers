/* contrib/gb18030_2022/gb18030_2022--1.0.sql */
--complain if script is sourced in psql rather than via ALTER EXTENSION
\echo Use "CREATE EXTENSION gb18030_2022" to load this file. \quit
LOAD 'gb18030_2022';