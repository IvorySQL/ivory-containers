---
name: "\U0001F680 Feature Request"
about: Propose a new feature.
labels: enhancement
---

## Feature Request

**Describe the feature you'd like to propose:**
