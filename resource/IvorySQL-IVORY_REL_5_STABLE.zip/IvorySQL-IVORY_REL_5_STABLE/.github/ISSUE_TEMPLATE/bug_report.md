---
name: "\U0001F41B Bug Report"
about: If something isn't working as expected
title: ''
labels: bug
assignees: ''

---

## Bug Report

### IvorySQL Version

### OS Version (uname -a)

### Configuration options  ( config.status --config )

### Current Behavior

### Expected behavior/code

### Step to reproduce

### Additional context that can be helpful for identifying the problem
